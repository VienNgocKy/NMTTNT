﻿using System;

namespace Microsoft.VisualBasic
{
    internal class Interaction
    {
        internal static string InputBox(string v1, string v2)
        {
            throw new NotImplementedException();
        }
    }
}